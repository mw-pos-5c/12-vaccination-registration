﻿using System;

namespace VaccRegDb
{
    public class Class1
    {
    }
}
